//$(document).ready(function() {
//    
//// script.j$(document).ready(function () {
//  // Initialize dark mode based on local storage
//const initialDarkMode = localStorage.getItem('darkMode') === 'true';
//$('#darkModeToggle').prop('checked', initialDarkMode);
//updateBodyClass(initialDarkMode);
//updateImageSource(initialDarkMode);
//
//// Handle dark mode toggle
//$('#darkModeToggle').change(function () {
//const darkMode = this.checked;
//updateBodyClass(darkMode);
//updateImageSource(darkMode);
//saveDarkModeToLocalStorage(darkMode);
//updateUrl(); // Update URL when dark mode changes
//});
//
//// Function to update body class based on dark mode
//function updateBodyClass(darkMode) {
//$('body').toggleClass('dark-mode', darkMode);
//}
//
//
//
//// Function to update image source based on dark mode
//function updateImageSource(darkMode) {
//const image = $('.screen-img');
//const newImagePath = darkMode ? 'assets/css/images/phone-white.png' : 'assets/css/images/phone-dark.png';
//image.attr('src', newImagePath);
//}    
//
//
//    
//    
//// Function to update image source based on dark mode
//function updateImageLoginSource(darkMode) {
//const imageLogin = $('.login-logo');
//const newImageLoginPath = darkMode ? 'assets/css/images/logo-trans-2.png' : 'assets/css/images/logo.png';
//imageLogin.attr('src', newImageLoginPath);
//}     
//    
//    
//    
//
//// Function to save dark mode choice to local storage
//function saveDarkModeToLocalStorage(darkMode) {
//localStorage.setItem('darkMode', darkMode);
//}      
//    
//
//    
//    
//$('.menu-button-open').click(function(event) {
//    if ($(window).width() <= 960) {
//        $('.nav-container').css({
//            'transform': 'translate(0%)',
//        });
//    }
//});
//
//$('.menu-button').click(function(event) {
//    if ($(window).width() <= 960) {
//        $('.nav-container').css({
//            'transform': 'translate(-100%)',
//        });
//    }
//});
//
//// Close menu if clicked outside when menu is open
//$(document).on('click', function(event) {
//    if ($(window).width() <= 960 && $('.nav-container').css('transform') === 'matrix(1, 0, 0, 1, 0, 0)' && !$(event.target).closest('.nav-container').length) {
//        $('.nav-container').css({
//            'transform': 'translate(-100%)',
//        });
//    }
//})
//    
//    
//
//})