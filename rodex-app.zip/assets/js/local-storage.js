$(document).ready(function () {
  // Initialize dark mode based on local storage
  const initialDarkMode = localStorage.getItem('darkMode') === 'true';
  $('#darkModeToggle').prop('checked', initialDarkMode);
  updateBodyClass(initialDarkMode);
    updateImageSource(initialDarkMode);

  // Handle dark mode toggle
  $('#darkModeToggle').change(function () {
    const darkMode = this.checked;
    updateBodyClass(darkMode);
    updateImageSource(darkMode);
    saveDarkModeToLocalStorage(darkMode);
    updateUrl(); // Update URL when dark mode changes
  });
    
    
  // Function to update body class based on dark mode
  function updateBodyClass(darkMode) {
    $('body').toggleClass('dark-mode', darkMode);
  }

    

// Function to update image source based on dark mode
  function updateImageSource(darkMode) {
    const image = $('.screen-img');
    const newImagePath = darkMode ? 'assets/css/images/phone-white.png' : 'assets/css/images/phone-dark.png';
    image.attr('src', newImagePath);
  }    
    
    
    
  // Function to save dark mode choice to local storage
  function saveDarkModeToLocalStorage(darkMode) {
    localStorage.setItem('darkMode', darkMode);
  }
    

});
