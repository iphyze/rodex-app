var swiper = new Swiper('.artist-swiper-container', {
    slidesPerView: 5,
    spaceBetween: 50,
//    loop: true,
//    mousewheel: true,
    keyboard: true,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    navigation: {
        nextEl: '.artist-swiper-button-next',
        prevEl: '.artist-swiper-button-prev',
    },
    breakpoints: {
        320: {
            slidesPerView: 2,
            spaceBetween: 20,
        },
        960: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1280: {
            slidesPerView: 5,
            spaceBetween: 50,
        },
    },
});