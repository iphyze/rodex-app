$(document).ready(function(){
    
    
    //$(document).on('click', '.music-col', function (e) {
    
    //Active Genre
    $(document).on('click', '.genre-btn', function(){
        $('.genre-btn').removeClass('active-genre');
        $(this).addClass('active-genre');
    });
    
    
    //Active Played Song
    $(document).on('click', '.playlist-songs-flexbox', function(){
        $('.playlist-songs-flexbox').removeClass('active-playlist-songs');
        $('.playlist-songs-flexbox').find('.active-ps-text').removeClass('active-ps-text');
        $('.playlist-songs-flexbox').find('.active-ps-text').removeClass('active-ps-text');
        $('.playlist-songs-flexbox').find('.active-playlist-genre').removeClass('active-playlist-genre');
        $('.playlist-songs-flexbox').find('.active-pbtn-text').removeClass('active-pbtn-text');
        
        $(this).addClass('active-playlist-songs');
        $(this).find('.playlist-number, .playlist-stitle, .playlist-aname, .track-separator, .playlist-genre, .playlist-time, .action-icons').addClass('active-ps-text');
        $(this).find('.playlist-play-btn').addClass('active-pbtn-text');
        $(this).find('.playlist-genre').addClass('active-playlist-genre');
        
        
        
        
        
        
        var imgSrc = $(this).find(".playlist-img").attr("src");
        var artistName = $(this).find(".playlist-aname").text();
        var songTitle = $(this).find(".playlist-stitle").text();
    
        // Update the album cover with the new information
        $(".album-cimg").attr("src", imgSrc);
        $(".album-cover-artist").text(artistName);
        $(".album-cover-title").text(songTitle);
         
    });
    
    
    
    
});



function filterSongs(genre) {
    // Flag to check if any songs are found for the selected genre
    let songsFound = false;
    
    $('.playlist-songs-flexbox').each(function() {
        const genreElement = $(this).find('.playlist-genre');
        if (genre === 'All Genres' || genreElement.text().trim() === genre.trim()) {
            $(this).show(100);
            songsFound = true; // Set the flag to true if at least one song is found
        } else {
            $(this).hide(100);
        }
    });

    // Show message if no songs are found for the selected genre
    if (!songsFound) {
        $('#no-songs-message').show(); // Assuming you have a div with id 'no-songs-message' to display the message
    } else {
        $('#no-songs-message').hide();
    }
}


function filterGenre(artistGenre) {
    // Flag to check if any songs are found for the selected genre
    let artistGenreFound = false;
    
    $('.artist-wrapper').each(function() {
        const artistGenreElement = $(this).data('genre');
        if (artistGenre === 'All Genres' || artistGenreElement.trim() === artistGenre.trim()) {
            $(this).show(100);
            artistGenreFound = true; // Set the flag to true if at least one song is found
        } else {
            $(this).hide(100);
        }
    });
    
    // Update the text of the genre filter
    $('.artist-flexbox-genre').text(artistGenre); // Update the text to the selected genre

    // Show message if no songs are found for the selected genre
    if (!artistGenreFound) {
        $('#no-artist-message').show(); // Assuming you have a div with id 'no-songs-message' to display the message
    } else {
        $('#no-artist-message').hide();
    }
}