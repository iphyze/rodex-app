$(document).ready(function () {
    
    //Music Col
    // Click event for any element with the class "music-col"
    $(document).on('click', '.music-col', function (e) {
        // Find the closest modal related to the clicked music-col
        var modal = $(".modal");


        // Get the source of the clicked music image
        var musicImageSrc = $(this).find(".music-image").attr("src");

        // Update the source of the modal image
        modal.find(".modal-img").attr("src", musicImageSrc);


        // Slide down the modal
        modal.slideDown();
        modal.css({
            display: 'flex',
        })
    });

    // Click event for any element with the class "modal"
    $(document).on('click', '.modal', function (e) {
        // Check if the clicked element is outside the modal content
        if (!$(e.target).closest('.modal-content').length) {
            // Slide up the clicked modal
            $(this).slideUp();
        }
    });


    $('.close-modal').click(function(){
            $('.modal').slideUp();
    });
    
    
    
    
    //Sidebar
    
    // Click event for any element with the class "music-col"
    $(document).on('click', '.sidebar-flexbox', function (e) {
        // Find the closest modal related to the clicked music-col
        var modal = $(".modal");


        // Get the source of the clicked music image
        var musicImageSrc = $(this).find(".sidebar-img").attr("src");

        // Update the source of the modal image
        modal.find(".modal-img").attr("src", musicImageSrc);


        // Slide down the modal
        modal.slideDown();
        modal.css({
            display: 'flex',
        })
    });

    // Click event for any element with the class "modal"
    $(document).on('click', '.modal', function (e) {
        // Check if the clicked element is outside the modal content
        if (!$(e.target).closest('.modal-content').length) {
            // Slide up the clicked modal
            $(this).slideUp();
        }
    });


    $('.close-modal').click(function(){
            $('.modal').slideUp();
    });
    
    

});