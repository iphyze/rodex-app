$(document).ready(function() {
    
    
    function resetMenu() {
      $('.nav-container').css({
            'transform': 'translate(0%)',
        });
    }
    
    $('.menu-button-open').click(function(event) {
        if ($(window).width() <= 960) {
            $('.nav-container').css({
                'transform': 'translate(0%)',
            });
        }
    });

    $('.menu-button').click(function(event) {
        if ($(window).width() <= 960) {
            $('.nav-container').css({
                'transform': 'translate(-100%)',
            });
        }
    });

    // Close menu if clicked outside when menu is open
    $(document).on('click', function(event) {
        if ($(window).width() <= 960 && $('.nav-container').css('transform') === 'matrix(1, 0, 0, 1, 0, 0)' && !$(event.target).closest('.nav-container').length) {
            $('.nav-container').css({
                'transform': 'translate(-100%)',
            });
        }
    });
    
    
    // Reset menu on window resize if screen is greater than 960px
    $(window).on('resize', function() {
      if ($(window).width() > 960) {
        resetMenu();
      }else{
          $('.nav-container').css({
                'transform': 'translate(-100%)',
            });
      }
    });
    
    
    
function handleMenuClick() {
    // find the menu id of the clicked element
    let menu_id = $(this).data("menu-id");
    
    // Remove the active-menu class from all menu links
    $(".menu-link").removeClass("active-menu");
    
    // Add the active-menu class to the .menu-link with the same data-menu-id as the clicked element
    $(".menu-link[data-menu-id='"+menu_id+"']").addClass("active-menu");
}

// Click event handler for menu links and for the mus-side-header-link
$(document).on('click', '.menu-link', handleMenuClick);
$(document).on('click', '.mus-side-header-link', handleMenuClick);
$(document).on('click', '.artist-wrapper', handleMenuClick);
    

    
$('.content-container').scroll(function() {
    var scroll = $(this).scrollTop();
    if (scroll >= 50) {
      $('.top-menu-container').css('background-color', 'rgba(255, 255, 255, 1)');
      $('.dark-mode .top-menu-container').css('background-color', '#111');
    } else {
      $('.top-menu-container').css('background-color', 'rgba(255, 255, 255, 0.1)');
        $('.dark-mode .top-menu-container').css('background-color', 'rgba(0, 41, 41, 0.05)');
    }
});
    
    

});  