//$(document).ready(function(){

    $(function() {
        $(document).on('click', '.menu-link, .mus-side-header-link, .artist-wrapper', function(e) {
            e.preventDefault();
            var pageName = $(this).attr('href');
            loadContent(pageName);
            history.pushState({}, '', $(this).attr('href')); 
        });

        function loadContent(pageName) {
            $("#view-container").load(pageName + ".html");
        }

        window.addEventListener('popstate', function(e) {
            var pageName = window.location.pathname.substr(1);
            if (pageName === "") pageName = "index";
            loadContent(pageName);
        }, false);

        // Determine which page to load based on the path
        var initialPage = window.location.pathname.substr(1);
        if (initialPage === "") initialPage = "index";
        loadContent(initialPage); 
    });

    // Additional code to handle loading the trending page
    // This ensures that when the trending page is accessed directly, it loads without redirection
    if (window.location.pathname.substr(1) === "trending") {
        loadContent("trending");
    }
    
    if (window.location.pathname.substr(1) === "rodex") {
        loadContent("rodex");
    }
    
    if (window.location.pathname.substr(1) === "artist") {
        loadContent("artist");
    }

//});
