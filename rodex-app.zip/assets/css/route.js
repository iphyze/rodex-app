// Function to handle navigation
function navigateTo(url) {
    fetch(url)
        .then(response => response.text())
        .then(html => {
            document.getElementById('content').innerHTML = html;
        })
        .catch(error => console.error('Error fetching content:', error));
}

// Add event listeners to all navigation links
document.querySelectorAll('.menu-link').forEach(link => {
    link.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default link behavior
        navigateTo(this.getAttribute('href')); // Load content dynamically
    });
});

// Load initial content
window.onload = function() {
    navigateTo('index.html');
};
